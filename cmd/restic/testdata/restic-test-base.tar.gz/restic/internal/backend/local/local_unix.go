//go:build !windows

package local

import (
	"errors"
	"os"
	"runtime"
	"syscall"
)

// fsyncDir flushes changes to the directory dir.
func fsyncDir(dir string) error {
	d, err := os.Open(dir)
	if err != nil {
		return err
	}

	err = d.Sync()
	if err != nil &&
		(errors.Is(err, syscall.ENOTSUP) || errors.Is(err, syscall.ENOENT) ||
			errors.Is(err, syscall.EINVAL) || isMacENOTTY(err)) {
		err = nil
	}

	cerr := d.Close()
	if err == nil {
		err = cerr
	}

	return err
}

// The ExFAT driver on some versions of macOS can return ENOTTY,
// "inappropriate ioctl for device", for fsync.
//
// https://github.com/restic/restic/issues/4016
// https://github.com/realm/realm-core/issues/5789
func isMacENOTTY(err error) bool {
	return runtime.GOOS == "darwin" && errors.Is(err, syscall.ENOTTY)
}

// set file to readonly
func setFileReadonly(f string, mode os.FileMode) error {
	err := os.Chmod(f, mode&^0222)

	// ignore the error if the FS does not support setting this mode (e.g. CIFS with gvfs on Linux)
	if err != nil && errors.Is(err, errors.ErrUnsupported) {
		return nil
	}

	return err
}

func removeFile(f string) error {
	return os.Remove(f)
}
