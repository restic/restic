#! /usr/bin/python3

# test python file
def main():
  print("hello restic")

if __name__ == '__main__':
  main()
